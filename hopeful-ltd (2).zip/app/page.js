
export default function Page() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold text-green-600">Welcome to Hopeful Ltd</h1>
      <p>This is your hosted app landing page.</p>
    </div>
  );
}
